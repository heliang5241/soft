#!/bin/bash
cd ~/files_exp
#################################

#sh ./check_hostname.sh
#sh ./update_puppet.sh
#sh ./install_gluster_cli.sh
free -m
