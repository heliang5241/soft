#!/bin/bash
echo $$
echo $0
echo $1
echo $#

