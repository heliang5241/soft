#!/bin/bash
hang=`cat /etc/sysconfig/network-scripts/ifcfg-*|grep GATEWAY -n|awk -F ':' '{print $1}'`
sed -i ''$hang's@^#@@' /etc/sysconfig/network-scripts/ifcfg-eth0 
echo $hang

